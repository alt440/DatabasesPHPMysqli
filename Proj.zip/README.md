# DatabasesPHPMysqli

COMP 353 - F / FALL 2019
Dr. Desai

PROJECT 1

Mair ELBAZ, 40004558
Daniel VIGNY-PAU, 40034769
Francois DAVID, 40046319
Alexandre THERRIEN, 40057134
Charles-Antoine GUITE, 40063098

To run the project:

1) Install and open XAMPP and start both Apache and MySQL
2) Place all the project files in C:\xampp\htdocs
3) Open your browser and in the search bar type `localhost/` and include the file path of the .php file you want to run (note: htdocs is seen as the root here, so only include files and folders after, it is not necessary to write C:/xampp/... etc.)
    ex: localhost/Proj/COMP353_P1.php or localhost/COMP353_P1.php
4) Press enter and it should run.


Files in directory:
- COMP353_P1.php: the code for the project
- COMP353_project_1_code_documentation: documentation of the code, in both pdf and docx formats
- db19s-P1.csv: the data being used for the project, as provided by the professor (note, a typo with three consecutive '|' symbols has been removed)